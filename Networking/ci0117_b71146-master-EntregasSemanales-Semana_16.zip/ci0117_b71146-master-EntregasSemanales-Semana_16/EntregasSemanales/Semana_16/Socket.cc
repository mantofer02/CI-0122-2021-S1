

/*
 *  Esqueleto para la clase Socket
 */

#include "Socket.h"

/*
   char tipo: el tipo de socket que quiere definir
      's' para "stream
      'd' para "datagram"
   bool ipv6: si queremos un socket para IPv6
 */
Socket::Socket( char tipo, bool ipv6){
  ipv6 = false;
  idSocket = socket(AF_INET, SOCK_STREAM,0);
  if(idSocket < 0){
    perror("Error al construir el socket");
    exit(1);
  }
  int prueba = 0;
  int opt = 1;
  prueba = setsockopt(this->idSocket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));
    if( prueba < 0){
        perror("Setsockopt");
        exit(EXIT_FAILURE);
    }
}

Socket::Socket( int id){
  this->idSocket = id;
}



Socket::~Socket(){
    Close();
}


void Socket::Close(){
  if(close(idSocket) < 0){
    perror("Error en el close del socket");
    exit(2);
  }
}

/*
   char * hostip: direccion delservidor, por ejemplo "www.ecci.ucr.ac.cr"
   int port: ubicacion del proceso, por ejemplo 80
 */

int Socket::Connect( char * hostip, int port ) {
  struct sockaddr_in host_addr;

  host_addr.sin_family = AF_INET;
  host_addr.sin_port = htons(port);
  int prueba = inet_pton(AF_INET, hostip, &host_addr.sin_addr);
  if(prueba < 0){
    perror("ERROR en el connect de arriba");
  }
  int len = sizeof(host_addr);

  if(connect(this->idSocket, (sockaddr *) & host_addr, len) < 0){
    perror("Error al conectar el socket");
    exit(3);
  }

  return connect(this->idSocket, (sockaddr *) & host_addr, len);
}


/*
   char * hostip: direccion del servidor, por ejemplo "www.ecci.ucr.ac.cr"
   char * service: nombre del servicio que queremos acceder, por ejemplo "http"
 */

/*
int Socket::Connect( char *host, char *service ) {
  struct sockaddr_in host_addr;

  host_addr.sin_family = AF_INET;
  inet_aton(host, &host_addr.sin_addr);
  host_addr.sin_port = 90;

  int len = sizeof(host_addr);
  if(connect(idSocket, (sockaddr *) & host_addr, len) < 0){
    perror("Error al conectar el socket");
    exit(4);
  }
  return connect(idSocket, (sockaddr *) & host_addr, len);
}
*/

  int Socket::Read( char *text, int len ) {
    if(read(idSocket, (void *) text, len) < 0){
      perror("Error en leer del socket");
      exit(5);
    }
     return read(idSocket, (void *) text, len);

  }


int Socket::Write( char *text ) {
  int len;
  if(write(idSocket, (void *) text, len) < 0){
    perror("Error en leer del socket");
    exit(6);
  }
   return write(idSocket, (void *) text, len);

}

int Socket::Write( char *text, int len ) {
  if(write(idSocket, (void *) text, len) < 0){
    perror("Error en leer del socket");
    exit(7);
  }
   return write(idSocket, (void *) text, len);

}


int Socket::Listen( int queue ) {
    int len;
    if(listen(idSocket, queue)){
      perror("Error en listen del socket");
      exit(8);
    }
    return listen(idSocket, queue);

}


int Socket::Bind( int port ) {
  struct sockaddr_in ip;

  ip.sin_family = AF_INET;
	ip.sin_port = port;
	ip.sin_addr.s_addr = INADDR_ANY;
	memset(&(ip.sin_zero), '\0', 8);
	if(bind(idSocket, (struct sockaddr *)&ip, sizeof(ip)) < 0){
		perror("Error en el bind");
		exit(9);
  }
  return bind(idSocket, (struct sockaddr *)&ip, sizeof(ip));
}


Socket * Socket::Accept(){
    struct sockaddr_in ip;
    socklen_t tamanyo;
    int prueba;
    if(prueba = accept(idSocket, (struct sockaddr *)&ip, &tamanyo) < 0){
      perror("Error en el accept del socket");
      exit(10);
    }
    return new Socket(prueba);
}


int Socket::Shutdown( int mode ) {
    if(shutdown(idSocket, SHUT_RDWR) < 0){
      perror("Error en el shutdown del socket");
      exit(10);
    }
    return shutdown(idSocket, SHUT_RDWR);

}


void Socket::SetIDSocket(int id){

    idSocket = id;

}
